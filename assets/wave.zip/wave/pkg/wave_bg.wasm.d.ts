/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const render_chart_gpu: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
export const wasm_bindgen__convert__closures_____invoke__hb22fd76c8c94911a: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen__convert__closures_____invoke__h1c327e9e15e390c9: (a: number, b: number, c: any, d: any) => void;
export const wasm_bindgen__convert__closures_____invoke__h6267dbccad26553f: (a: number, b: number, c: any) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
